rootProject.name = "configurator"
