package org.kfru.pse.cars.configurator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfiguratorApplication {

  public static void main(String[] args) {
    SpringApplication.run(ConfiguratorApplication.class, args);
  }

}
