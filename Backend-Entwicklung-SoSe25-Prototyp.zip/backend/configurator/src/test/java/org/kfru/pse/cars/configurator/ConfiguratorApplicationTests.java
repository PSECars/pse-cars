package org.kfru.pse.cars.configurator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfiguratorApplicationTests {

  @Test
  void contextLoads() {
  }

}
