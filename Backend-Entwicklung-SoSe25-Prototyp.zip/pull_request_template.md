## Definition of Done
[ ] OpenAPI für REST Endpunkte ist verfügbar
[ ] Komponentenarchitektur ist in `/docs` Unterordner dokumentiert (da wo sinnvoll)
[ ] Dockerfile für Komponente ist geschrieben
[ ] `compose.yaml` wurde geupdatet sodass Komponente automatisch deployed werden kann
